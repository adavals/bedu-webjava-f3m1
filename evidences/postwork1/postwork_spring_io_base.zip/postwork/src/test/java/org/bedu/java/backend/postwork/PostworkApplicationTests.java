package org.bedu.java.backend.postwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
